
def tabuada(numero):
    count = 0 
    while count < 10: 
       count += 1
       print(f'{numero} x {count} = {numero*count}')
